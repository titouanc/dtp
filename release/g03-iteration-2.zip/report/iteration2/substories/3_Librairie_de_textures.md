**Durée estimée: 30h** | **Difficulté estimée: 2/3** | **Assigné à: Pierre, Walter** | Groupe **3**

Autant dans l'éditeur général que dans l'éditeur d'objets, on doit avoir accès à la librairie de texture qui se matérialise sous la forme d'un panneau de l'interface graphique dans lequel on peut avoir un aperçu des textures déjà importées dans le projet. 

Ce panneau doit également donner la possibilité de rajouter une texture au projet, ou d'en supprimer. Ces changements seront réfléchis sur les objets qui portent ces textures.

On doit pouvoir rajouter une texture à un objet.

**Statut: fait** | **Remarques:** 
