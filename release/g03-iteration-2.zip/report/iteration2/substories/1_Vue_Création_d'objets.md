**Durée estimée: 4h** | **Difficulté estimée: 1/3** | **Assigné à: Pierre et Julian** | Groupe **3**

Il faut rajouter une autre vue 3D que celle de l'éditeur principal, dans laquelle on peut créer des objets, et les modifier.

**Statut: fait** | **Remarques:** 