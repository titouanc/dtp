**Durée estimée: 7h** | **Difficulté estimée: 2/3** | **Assigné à: Julian et Walter** | Groupe **3**

Il est nécessaire de pouvoir rajouter des objets que l'utilisateur a créé dans l'éditeur général. Dès lors, il faut rajouter une vue qui permet de consulter tous les objets créés et d'en sélectionner un dont on peut créer une instance dans l'éditeur général.

**Statut: fait** | **Remarques:**
