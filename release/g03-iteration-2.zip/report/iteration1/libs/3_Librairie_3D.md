Nous choisissons d'utiliser jMonkeyEngine comme librairie 3D pour ces 
raisons : 

- Elle est sous license BSD
- Une des interfaces les plus high level
- Community driven
- Développement encore actif
- Documentation extensive
- Engine complet
- Refonte complête de JME2 pour le mieux
- Intégration facile dans un GUI swing : 
http://hub.jmonkeyengine.org/wiki/doku.php/jme3:advanced:swing_canvas


Justification de l'écartement d'autres librairies : 

### JOGL:
-  Utilise SWT comme système de fenêtrage

### GL4Java:

- Vieux et obsolète

### Java3D:

- Abandonné

###Ardor3D:

- Prise en main difficile et risque de requérir beaucoup plus de temps
