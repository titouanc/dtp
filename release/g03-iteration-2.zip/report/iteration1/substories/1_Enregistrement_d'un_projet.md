**Durée estimée: 20h** | **Difficulté estimée: 2/3** | **Assigné à: Titouan** | Groupe **3**

Les projets d'architecture doivent être enregistrables dans des fichiers, et il doit être possible de charger un projet depuis un fichier. Différents éléments doivent être enregistrés, comme la configuration du projet (nom, auteur, ...), ainsi que des éléments affichables (polyèdres pour le moment, éventuellement les tags par la suite).

Les projets doivent être enregistrés séparément et sélectionnables dans un navigateur de fichiers pour ouverture ou enregistrement.

**Statut: fait** | **Remarques:**