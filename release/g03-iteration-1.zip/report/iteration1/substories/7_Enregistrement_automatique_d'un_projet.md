**Durée estimée: 2h** | **Difficulté estimée: 1/3** | **Assigné à: Titouan et Pierre** | Groupe **3**

Le projet sur lequel travaille l'utilisateur est sauvé automatiquement sur le disque. L'utilisateur peut aussi enregistrer une copie du projet, auquel cas un nouveau fichier de projet est créé, et devient le projet courant.

Par défaut, lorsque l'utilisateur ouvre le programme, le dernier projet utilisé lui est présenté.

**Statut: fait** | **Remarques:** Il faudra peut-être revoir le système car les performance en écritures/lectures fréquentes du disque ne sont pas excellentes.
