**Durée estimée: 10h** | **Difficulté estimée: 1/3**  | **Assigné à: Florentin, Bruno et Walter** | Groupe **3**

L'utilisateur devra pouvoir choisir d'afficher le plan d'architecture autant en 3D qu'en 2D. Chaque pièce pourra avoir une forme différente et n'aura pas forcément la forme d'un rectangle.

**Statut: fait** | **Remarques:** Cette tâche a pris plus de temps que prévu à cause de notre perfectionnisme pour les caméras différentes, le look and feel de la vue et quelques détails qui ont amélioré l'usabilité de l'application
