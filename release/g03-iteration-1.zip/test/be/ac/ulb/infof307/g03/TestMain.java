package be.ac.ulb.infof307.g03;

//import static org.junit.Assert.*;

import org.junit.Test;

/**
 * Test of main class
 */
public class TestMain {

	/**
	 * TODO
	 */
	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
