**Durée estimée: 5h** | **Difficulté estimée: 1/3** | **Assigné à: Bruno et Julian** | Groupe **3**

Dans la vue 3D, l'utilisateur devra avoir le contrôle de la caméra, que ce soit pour zoomer ou déplacer la caméra sur les cotés, et ce, aussi bien grâce à la souris que grâce aux flèches.

**Statut: fait** | **Remarques:**
