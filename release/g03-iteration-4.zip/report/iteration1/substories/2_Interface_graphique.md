**Durée estimée: 30h** | **Difficulté estimée: 1/3** | **Assigné à: Julian et Pierre** | Groupe **3**

L'interface graphique sera composé d'un menu, d'une barre d'outils et d'un écran splitter en deux. Sur cet écran splitter il y aura à gauche les objet utilisés  et a droite le rendu 2D et 3D.

**Statut: fait** | **Remarques:**