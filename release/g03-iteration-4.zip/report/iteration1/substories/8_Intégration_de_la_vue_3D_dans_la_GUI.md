**Durée estimée: 10h** | **Difficulté estimée: 2/3** | **Assigné à: Pierre** | Groupe **3**

Il faut intégrer jmonkey qui s'occupe de la 3d dans swing qui s'occupe de l'interface graphique

http://hub.jmonkeyengine.org/wiki/doku.php/jme3:advanced:swing_canvas

**Statut: fait** | **Remarques:**
