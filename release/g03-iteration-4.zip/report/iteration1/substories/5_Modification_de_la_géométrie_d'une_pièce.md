**Durée estimée: 40h** | **Difficulté estimée: 3/3** | **Assigné à: Walter, Titouan, Bruno, Florentin** | Groupe **3**

L'utilisateur a accès à une vue d'édition lui permettant de rajouter ou éditer des murs et des étages. 

Tous les points du "sol" sont à la même hauteur, et à chacun d'eux est associée une élévation.

La hauteur de l'étage est déterminée par son point le plus haut. Le sol de l'étage suivant est égal à la hauteur du point le plus haut de l'étage précédent

**Statut: fait** | **Remarques :**
