**Durée estimée: 5h** | **Difficulté estimée: 1/3** | **Assigné à: Walter et Julian** | Groupe **3**

Lorsque l'utilisateur lance pour la première fois le programme EA3D, un projet de démonstration complet s'ouvre, pour lui montrer tout ce qu'il est possible de faire.

**Statut: fait** | **Remarques:**
