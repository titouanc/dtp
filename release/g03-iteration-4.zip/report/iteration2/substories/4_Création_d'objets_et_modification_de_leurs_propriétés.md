**Durée estimée: 40h** | **Difficulté estimée: 2/3** | **Assigné à: Titouan, Bruno, Florentin** | Groupe **3**

Dans la vue de création d'objets, on doit pouvoir rajouter des formes de base de jMonkey (parallélépipède rectangle, ellipsoïde, plan, ...). On peut changer la positition de ces formes, leur échelle sur les 3 axes et leur rotation, aussi sur les 3 axes. Chacune des formes peut porter une texture.

**Statut: fait** | **La modification des objets n'est pas tout à fait user-friendly. Pour modifier un objet, il faut pour le moment modifier les composants de l'objet un par un.**